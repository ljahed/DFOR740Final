﻿//Leena Jahed
//Final DFOR 740

#include <windows.h>      // Windows API functions (process, registry, etc.)
#include <tlhelp32.h>     // Toolhelp32 functions for process snapshot
#include <sddl.h>         // Security Descriptor Definition Language (for SID conversion)
#include <iostream>       // Standard I/O (wprintf)
#include <string>         // std::wstring
#include <unordered_map>  // Hash map for baseline storage
#include <unordered_set>  // Hash set for storing multiple valid paths/parents/users
#include <vector>         // Dynamic buffer for registry multi‑string values
#include <conio.h>        // _kbhit and _getch for keyboard input (press X to stop)

int wmain(int argc, wchar_t* argv[]) {
    //Configuration variables to see how many times a new process must appear before learning it and how many seconds in between scans
    int minSeen = 5;
    int pollSec = 5;

    // Parse command line arguments with the configuration variables
    for (int i = 1; i < argc; ++i) {
        if (wcscmp(argv[i], L"--min") == 0 && i + 1 < argc) minSeen = _wtoi(argv[++i]);
        else if (wcscmp(argv[i], L"--poll") == 0 && i + 1 < argc) pollSec = _wtoi(argv[++i]);
    }

    // Baseline storage for each process name, path, parents, users and how many times the process is seen
    std::unordered_map<std::wstring, std::unordered_set<std::wstring>> knownPaths, knownParents, knownUsers;
    std::unordered_map<std::wstring, int> knownCounts;

    // Load baseline from registry if there is one previously saved
    HKEY hk;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, L"Software\\DFOR740Detector", 0, KEY_READ, &hk) == ERROR_SUCCESS) {
        wchar_t name[256];
        DWORD idx = 0, sz = 256;
        //Iterate over the subkeys for each process
        while (RegEnumKeyExW(hk, idx++, name, &sz, 0, 0, 0, 0) == ERROR_SUCCESS) {
            std::wstring pname(name);
            HKEY hsub;
            if (RegOpenKeyExW(hk, name, 0, KEY_READ, &hsub) == ERROR_SUCCESS) {
                DWORD type, dsize;

                // Paths
                if (RegQueryValueExW(hsub, L"Paths", 0, &type, 0, &dsize) == ERROR_SUCCESS && type == REG_MULTI_SZ) {
                    std::vector<wchar_t> buf(dsize / 2);
                    RegQueryValueExW(hsub, L"Paths", 0, &type, (BYTE*)buf.data(), &dsize);
                    for (const wchar_t* p = buf.data(); *p; p += wcslen(p) + 1)
                        knownPaths[pname].insert(p);
                }

                // Parents
                if (RegQueryValueExW(hsub, L"Parents", 0, &type, 0, &dsize) == ERROR_SUCCESS && type == REG_MULTI_SZ) {
                    std::vector<wchar_t> buf(dsize / 2);
                    RegQueryValueExW(hsub, L"Parents", 0, &type, (BYTE*)buf.data(), &dsize);
                    for (const wchar_t* p = buf.data(); *p; p += wcslen(p) + 1)
                        knownParents[pname].insert(p);
                }

                // Users
                if (RegQueryValueExW(hsub, L"Users", 0, &type, 0, &dsize) == ERROR_SUCCESS && type == REG_MULTI_SZ) {
                    std::vector<wchar_t> buf(dsize / 2);
                    RegQueryValueExW(hsub, L"Users", 0, &type, (BYTE*)buf.data(), &dsize);
                    for (const wchar_t* p = buf.data(); *p; p += wcslen(p) + 1)
                        knownUsers[pname].insert(p);
                }

                // Count
                DWORD cnt = 0;
                dsize = sizeof(DWORD);
                if (RegQueryValueExW(hsub, L"Count", 0, &type, (BYTE*)&cnt, &dsize) == ERROR_SUCCESS)
                    knownCounts[pname] = cnt;
                RegCloseKey(hsub);
            }
            sz = 256;
            ZeroMemory(name, sizeof(name));
        }
        RegCloseKey(hk);
    }

    //see how many times the process, path, parent, and user all combined are seen
    std::unordered_map<std::wstring, int> pending;

    // Startup banner to print for the user
    wprintf(L"   Process Anomaly Detector - DFOR 740 Final Project\n");
    wprintf(L"------------------------------------------------------------------------\n");
    wprintf(L"Min occurrences to learn: %d | Poll interval: %d sec\n", minSeen, pollSec);
    wprintf(L"Press 'X' at any time to stop the tool!\n");
    wprintf(L"------------------------------------------------------------------------\n\n");

    //wait before beginning scanning so the user can view options
    Sleep(5000);
    wprintf(L"Beginning continuous scanning...\n\n");

    //variable to keep track of how many scans have occurred during the execution
    int scanNumber = 0;

    // Main monitoring loop
    while (true) {
        scanNumber++;
        wprintf(L"---------------------------- Scan #%d ------------------------------\n", scanNumber);

        //Take a snapshot of all running processes
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (snap != INVALID_HANDLE_VALUE) {
            PROCESSENTRY32W pe = { sizeof(PROCESSENTRY32W) };
            if (Process32FirstW(snap, &pe)) {
                // First pass: build parent PID mapping so parent process name can be looked up later for each process
                std::unordered_map<DWORD, DWORD> parentMap;
                do { parentMap[pe.th32ProcessID] = pe.th32ParentProcessID; } while (Process32NextW(snap, &pe));

                // Second pass: evaluate each process
                Process32FirstW(snap, &pe);
                do {
                    DWORD pid = pe.th32ProcessID;
                    std::wstring name = pe.szExeFile;
                    //Convert process name to lowercase for comparison
                    for (auto& c : name) c = towlower(c);
                    if (name.empty()) continue;

                    // Skip noisy system process as it provides false positives
                    if (name == L"conhost.exe") continue;

                    // Full image path
                    std::wstring path;
                    HANDLE hp = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
                    if (hp) {
                        WCHAR buf[MAX_PATH];
                        DWORD sz = MAX_PATH;
                        if (QueryFullProcessImageNameW(hp, 0, buf, &sz)) path = buf;
                        CloseHandle(hp);
                    }

                    // Parent process name
                    std::wstring parentName;
                    DWORD ppid = parentMap[pid];
                    if (ppid) {
                        HANDLE hps = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
                        if (hps != INVALID_HANDLE_VALUE) {
                            PROCESSENTRY32W pe2 = { sizeof(PROCESSENTRY32W) };
                            if (Process32FirstW(hps, &pe2)) {
                                do {
                                    if (pe2.th32ProcessID == ppid) {
                                        parentName = pe2.szExeFile;
                                        break;
                                    }
                                } while (Process32NextW(hps, &pe2));
                            }
                            CloseHandle(hps);
                        }
                    }

                    // User (owner)
                    std::wstring user = L"Unknown";
                    HANDLE hu = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
                    if (hu) {
                        HANDLE token;
                        if (OpenProcessToken(hu, TOKEN_QUERY, &token)) {
                            DWORD needed = 0;
                            GetTokenInformation(token, TokenUser, 0, 0, &needed);
                            if (needed) {
                                std::vector<BYTE> buf(needed);
                                if (GetTokenInformation(token, TokenUser, buf.data(), needed, &needed)) {
                                    PTOKEN_USER tu = (PTOKEN_USER)buf.data();
                                    WCHAR nameBuf[256], domainBuf[256];
                                    DWORD nsz = 256, dsz = 256;
                                    SID_NAME_USE snu;
                                    if (LookupAccountSidW(0, tu->User.Sid, nameBuf, &nsz, domainBuf, &dsz, &snu))
                                        user = std::wstring(domainBuf) + L"\\" + nameBuf;
                                }
                            }
                            CloseHandle(token);
                        }
                        CloseHandle(hu);
                    }

                    // Check if known in baseline
                    bool known = (knownPaths.count(name) || knownParents.count(name) || knownUsers.count(name));
                    bool anomaly = false;
                    if (known) {
                        //Check the path
                        if (!knownPaths[name].empty() && knownPaths[name].find(path) == knownPaths[name].end())
                            anomaly = true;
                        //Check the parents
                        if (!knownParents[name].empty() && knownParents[name].find(parentName) == knownParents[name].end())
                            anomaly = true;
                        //Check the user
                        if (!knownUsers[name].empty() && knownUsers[name].find(user) == knownUsers[name].end())
                            anomaly = true;

                        // Ignore empty path anomalies for system processes
                        if (anomaly && path.empty() && (parentName == L"services.exe" || parentName == L"svchost.exe" || parentName.empty()))
                            anomaly = false;
                    }

                    //Process for handling anomaly behavior, checks for known information
                    if (known && anomaly) {
                        wprintf(L"[ALERT] %ls (PID:%d) path:%ls parent:%ls user:%ls\n",
                            name.c_str(), pid, path.c_str(), parentName.c_str(), user.c_str());

                        // Log alert to Windows Event Log
                        HANDLE elog = RegisterEventSourceW(0, L"DFOR740");
                        if (elog) {
                            std::wstring msg = L"Anomaly detected: " + name + L" from " + path;
                            const wchar_t* msgs[] = { msg.c_str() };
                            ReportEventW(elog, EVENTLOG_WARNING_TYPE, 0, 1001, 0, 1, 0, msgs, 0);
                            DeregisterEventSource(elog);
                        }

                        //If an anomaly is seen 'minSeen' times, it will merge into the baseline as an accurate process.
                        std::wstring cand = name + L"|" + path + L"|" + parentName + L"|" + user;
                        if (++pending[cand] >= minSeen) {
                            // Add the new variation to baseline (merge, not replace)
                            knownPaths[name].insert(path);
                            knownParents[name].insert(parentName);
                            knownUsers[name].insert(user);
                            knownCounts[name] += pending[cand];
                            pending.erase(cand);

                            // Save to registry updated baseline
                            HKEY hkWrite;
                            if (RegCreateKeyExW(HKEY_CURRENT_USER, L"Software\\DFOR740Detector", 0, 0, 0, KEY_WRITE, 0, &hkWrite, 0) == ERROR_SUCCESS) {
                                RegDeleteTreeW(hkWrite, 0);
                                for (auto& kv : knownPaths) {
                                    HKEY hsub;
                                    if (RegCreateKeyExW(hkWrite, kv.first.c_str(), 0, 0, 0, KEY_WRITE, 0, &hsub, 0) == ERROR_SUCCESS) {
                                        // Write all stored paths, parents, users...
                                        std::vector<wchar_t> mp;
                                        for (auto& p : kv.second) {
                                            mp.insert(mp.end(), p.begin(), p.end());
                                            mp.push_back(0);
                                        }
                                        mp.push_back(0);
                                        RegSetValueExW(hsub, L"Paths", 0, REG_MULTI_SZ, (BYTE*)mp.data(), (DWORD)mp.size() * sizeof(wchar_t));

                                        auto itp = knownParents.find(kv.first);
                                        if (itp != knownParents.end()) {
                                            std::vector<wchar_t> mp2;
                                            for (auto& p : itp->second) {
                                                mp2.insert(mp2.end(), p.begin(), p.end());
                                                mp2.push_back(0);
                                            }
                                            mp2.push_back(0);
                                            RegSetValueExW(hsub, L"Parents", 0, REG_MULTI_SZ, (BYTE*)mp2.data(), (DWORD)mp2.size() * sizeof(wchar_t));
                                        }

                                        //Write Users
                                        auto itu = knownUsers.find(kv.first);
                                        if (itu != knownUsers.end()) {
                                            std::vector<wchar_t> mp3;
                                            for (auto& u : itu->second) {
                                                mp3.insert(mp3.end(), u.begin(), u.end());
                                                mp3.push_back(0);
                                            }
                                            mp3.push_back(0);
                                            RegSetValueExW(hsub, L"Users", 0, REG_MULTI_SZ, (BYTE*)mp3.data(), (DWORD)mp3.size() * sizeof(wchar_t));
                                        }

                                        //Write Count
                                        DWORD cnt = knownCounts[kv.first];
                                        RegSetValueExW(hsub, L"Count", 0, REG_DWORD, (BYTE*)&cnt, sizeof(DWORD));
                                        RegCloseKey(hsub);
                                    }
                                }
                                RegCloseKey(hkWrite);
                            }
                        }
                    }

                    //Add a new process if not seen before, added to baseline after 'minSeen' times
                    else if (!known) {
                        wprintf(L"[NEW] %ls (PID:%d) path:%ls parent:%ls user:%ls\n",
                            name.c_str(), pid, path.c_str(), parentName.c_str(), user.c_str());
                        std::wstring cand = name + L"|" + path + L"|" + parentName + L"|" + user;
                        if (++pending[cand] >= minSeen) {
                            // Add the process to baseline using path, user, count, parentName
                            knownPaths[name].insert(path);
                            knownParents[name].insert(parentName);
                            knownUsers[name].insert(user);
                            knownCounts[name] += pending[cand];
                            pending.erase(cand);

                            // Save to registry for updated baseline
                            HKEY hkWrite;
                            if (RegCreateKeyExW(HKEY_CURRENT_USER, L"Software\\DFOR740Detector", 0, 0, 0, KEY_WRITE, 0, &hkWrite, 0) == ERROR_SUCCESS) {
                                RegDeleteTreeW(hkWrite, 0);
                                for (auto& kv : knownPaths) {
                                    HKEY hsub;
                                    if (RegCreateKeyExW(hkWrite, kv.first.c_str(), 0, 0, 0, KEY_WRITE, 0, &hsub, 0) == ERROR_SUCCESS) {
                                        std::vector<wchar_t> mp;
                                        for (auto& p : kv.second) {
                                            mp.insert(mp.end(), p.begin(), p.end());
                                            mp.push_back(0);
                                        }
                                        mp.push_back(0);
                                        RegSetValueExW(hsub, L"Paths", 0, REG_MULTI_SZ, (BYTE*)mp.data(), (DWORD)mp.size() * sizeof(wchar_t));
                                        auto itp = knownParents.find(kv.first);
                                        if (itp != knownParents.end()) {
                                            std::vector<wchar_t> mp2;
                                            for (auto& p : itp->second) {
                                                mp2.insert(mp2.end(), p.begin(), p.end());
                                                mp2.push_back(0);
                                            }
                                            mp2.push_back(0);
                                            RegSetValueExW(hsub, L"Parents", 0, REG_MULTI_SZ, (BYTE*)mp2.data(), (DWORD)mp2.size() * sizeof(wchar_t));
                                        }
                                        auto itu = knownUsers.find(kv.first);
                                        if (itu != knownUsers.end()) {
                                            std::vector<wchar_t> mp3;
                                            for (auto& u : itu->second) {
                                                mp3.insert(mp3.end(), u.begin(), u.end());
                                                mp3.push_back(0);
                                            }
                                            mp3.push_back(0);
                                            RegSetValueExW(hsub, L"Users", 0, REG_MULTI_SZ, (BYTE*)mp3.data(), (DWORD)mp3.size() * sizeof(wchar_t));
                                        }
                                        DWORD cnt = knownCounts[kv.first];
                                        RegSetValueExW(hsub, L"Count", 0, REG_DWORD, (BYTE*)&cnt, sizeof(DWORD));
                                        RegCloseKey(hsub);
                                    }
                                }
                                RegCloseKey(hkWrite);
                            }
                        }
                    }
                } while (Process32NextW(snap, &pe));
            }
            CloseHandle(snap);
        }
        // Check for user exit request to exit loop
        if (_kbhit()) {
            int ch = _getch();
            if (ch == 'x' || ch == 'X') {
                wprintf(L"\nStop requested by user. Exiting gracefully...\n");
                break;
            }
        }
        wprintf(L"--- Waiting %d seconds for next scan (press X to stop) ---\n\n", pollSec);
        //Time to wait before next scan
        Sleep(pollSec * 1000);
    }
    //Message to user about stopping the tool
    wprintf(LR"(Tool stopped. Baseline saved in registry location HKEY_CURRENT_USER\Software\DFOR740Detector.)");
    return 0;
}